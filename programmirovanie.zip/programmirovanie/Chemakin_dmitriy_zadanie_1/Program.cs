﻿using System;

namespace Chemakin_dmitriy_zadanie_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //напишите программу, чтобы найти значение указанного выражения. 
            //a) 101 + 0) / 3
            //b) 3.0e-6 * 10000000.1
            //c) true && true
            //d) false && true
            //e) (false && false) (true && true)
            //f) (false false) && (true && true)

            double a = 101, b = 0, c = 3, g = 3.0e-6, h = 10000000.1; //variables, values 
            double y = (a + b) / c; //expression (1)
            double k = g * h; //expression (2)
            bool z = true && true; //expression (3)
            bool p = false && true; //expression (4)
            bool f = (false && false) || (true && true); //expression (5)
            bool q = (false || false) && (true && true); //expression (6)

            Console.WriteLine($"{y:n2} , {k}, {z}, {p}, {f}, {q}."); //decimal point limit and result in console
 
        }
    }
}

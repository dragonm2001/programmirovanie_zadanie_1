﻿namespace Chemakin_dmitriy_zadanie_1
{
    internal class boolean
    {
    }
}
﻿using System;

namespace Chemakin_dmitriy_304_zadanie_6
{
    class Program
    {
        //Напишите программу для умножения двух заданных целых чисел без использования оператора умножения(*).

        static void Main(string[] args)
        {
            Console.WriteLine("enter the first target number: ");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the second target number: ");
            int b = Convert.ToInt32(Console.ReadLine());
            int c = 0;
            for (int i = 0; i < b; i++)
            {
                c += a;
            }
            Console.WriteLine(c);
        }
    }
}

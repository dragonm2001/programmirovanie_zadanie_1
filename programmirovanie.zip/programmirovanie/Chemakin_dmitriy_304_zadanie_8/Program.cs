﻿using System;

namespace Chemakin_dmitriy_304_zadanie_8
{
    class Program
    {
        static void Main(string[] args)
        {
            //Напишите програмиу для преобразования температуры из градуса Фаренгейта в градус Цельсия.

            int c, f; //variables
            Console.WriteLine("Enter temperature in Fahrenheit:"); //write the temperature
            f = int.Parse(Console.ReadLine()); //enter a number on a new line
            c = (f - 32) * 5 / 9; //expression
            Console.WriteLine("Temperature in degrees Celsius:" + c); //temperature output after translation
            Console.ReadLine(); //new line output
        }
    }
}

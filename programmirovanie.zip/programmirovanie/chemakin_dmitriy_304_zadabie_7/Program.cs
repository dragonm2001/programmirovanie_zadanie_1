﻿using System;

namespace chemakin_dmitriy_304_zadabie_7
{
    class Program
    {

        //Напишите для разбиения заданного массива целых чисел на четное число первым и нечетное число вторым.

        static void Main(string[] args)
        {
            int[] a = new int[10];

            Random rand = new Random();
            Console.WriteLine("Your array: ");
            for (int i = 0; i < a.Length; i++)
            {
                a[i] = rand.Next(100);

                if (a[i] % 2 == 0)
                {
                    Console.WriteLine(a[i]);
                }

            }
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] % 2 == 1)
                {
                    Console.WriteLine(a[i]);
                }
                

            }
            Console.ReadKey();

        }
    }
}

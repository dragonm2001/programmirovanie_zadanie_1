﻿using System;

namespace Chemakin_Dmitriy_304_zadanie_10
{
    class Program
    {
        static void Main(string[] args)
        {
            //Напишите, которая считывает число и отображает квадрат, куб и четвертую степень.

            double a, f, c , g; //variables
            Console.WriteLine("write your value: "); 
            f = double.Parse(Console.ReadLine()); //entered number on a new line
            a = f * f; //Squared
            c = f * f * f; //cubed
            g = f * f * f * f; //4th power
            Console.WriteLine("Squared, cubed and 4th power: " + $"{a} , {c}, {g}.");
        }
    }
}

﻿using System;

namespace chemakin_dmitriy_304_zadanie_5
{
    class Program
    {
        //Напишите программу для поиска чисел, превышающих среднее значение чисел данного массива. 
        static void Main(string[] args)
        {
            int[] a = {  361, 762, 116, 445, 200, 694,
                127, 735, 494, 863, 787, 849, 679, 655,
                877, 692, 80, 388, 267, 100, 621, 286,
                140, 995, 903, 160, 312, 953, 993, 327,
                246, 222, 625, 709, 890, 977, 392, 922,
                693, 284, 100, 679, 780, 60, 853, 76,
                414, 992, 343, 12, 64, 989, 325, 194,
                832, 782, 37, 464, 60, 803, 175, 79,
                154, 216, 384, 122, 438, 741, 213, 28,
                925, 893, 52, 784, 238, 268, 487, 60,
                458, 782, 154, 698, 645, 200, 758, 255,
                677, 521, 422, 22, 733, 682, 86, 488,
                745, 857, 598, 456, 343, 151 };
            //the sum of the elements of the array divided by the length of the array, and then compare
            int numAll = 0;
            for (int i = 0; i < a.Length; i++) numAll += a[i];
            double average = numAll / a.Length;
            for (int i = 0; i < a.Length; i++) if (average < a[i]) { Console.WriteLine(a[i]); };
            Console.ReadKey();
        }
    }
}

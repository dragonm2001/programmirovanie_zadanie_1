﻿using System;

namespace Chemakin_dmitriy_304_zadanie_2
{
    class Program
    {
        //Напишите программу, которая принимает четыре целых числа
        //от пользователя и выводит надпись равно, если все четыре равны,
        //и не равно в противном случае. 
        static void Main(string[] args)
        {

        ABCD:
            Console.WriteLine("Write 4 numbers (each number must be on a new line, otherwise the check will not happen)");

            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());

            if (a == b && b == c && c == d)
            {
                Console.WriteLine("the numbers are equal");
            }
            else { Console.WriteLine("numbers are not equal"); }
            Console.ReadLine();
            goto ABCD; //The goto statement transfers control to the statement marked with the label, as shown in the following
        }
    }
}

﻿using System;

namespace chemakin_dmitriy_304_zadanie_11
{
    class Program
    {
        //Напишите программу, чтобы проверить, могут ли три заданные длины сторон (целые числа)
        //образовать треугольник или нет.

        static void Main(string[] args)
        {
            int a, b, c;
            Console.WriteLine("write the first side of the triangle: "); 
            a = int.Parse(Console.ReadLine());

            Console.WriteLine("write the other side of the triangle: ");
            b = int.Parse(Console.ReadLine());

            Console.WriteLine("write the third side of the triangle: ");
            c = int.Parse(Console.ReadLine());

            if (a + b > c && a + c > b && b + c > a)
            {
                Console.WriteLine("triangle exists");
            }
            else
            {
                Console.WriteLine("triangle does not exist"); 
            }

        }
    }
}

﻿using System;

namespace Chemakin_dmitriy_304_zadanie_9
{
    class Program
    {
        static void Main(string[] args)
        {
            //Напишите программу для вычисления индекса массы тела(ИМТ).ИМТ = ВЕС / РОСТ2

            double c, f, g=0; //variables
            bool h = false;
            Console.WriteLine("write your weight: "); //write weight
            f = double.Parse(Console.ReadLine()); //enter a number on a new line
            while (h==false)
            {
                try
                {
                    Console.WriteLine("Write your height (enter number in meters): "); //write height
                    g = double.Parse(Console.ReadLine()); //enter a number on a new line
                    h = true;
                }
                catch
                {
                    Console.WriteLine("wrong number format");
                }
            }
            c = f/(g*g); //expression
            Console.WriteLine("Your body mass index:" + $"{c:n0}"); //body mass index output
            Console.ReadLine(); //new line output


        }
    }
}
